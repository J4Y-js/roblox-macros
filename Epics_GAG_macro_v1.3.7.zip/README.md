# 🍏 Epic's Grow a Garden Macro

![GitHub Repo stars](https://img.shields.io/github/stars/epicisgood/Grow-a-Garden-Macro?style=flat)
![GitHub Downloads (all assets, all releases)](https://img.shields.io/github/downloads/epicisgood/Grow-a-Garden-Macro/total)
![GitHub Created At](https://img.shields.io/github/created-at/epicisgood/Grow-a-Garden-Macro)
![GitHub License](https://img.shields.io/github/license/epicisgood/Grow-a-Garden-Macro)


A macro for **Grow a Garden** that automatically buys your selected seeds, gear, and crafting benches and more!

✅ Supports **auto-reconnect** and sends **images via Discord webhook**.

✅ The macro does NOT require **UI navigation** and the macro works using your **cursor**.

> **Recall Wrench** is in the **first hotbar slot** but macro auto equips it

<img width="450" height="500" alt="image" src="https://github.com/user-attachments/assets/9331c1db-9e93-4239-88a7-6e7bdc17c1d0" />


---

## 📥 Installation

1. **Download the Repository**

   * Visit the [Latest Release](https://github.com/epicisgood/Grow-a-Garden-Macro/releases/latest)
   * Download and **extract** the ZIP file

2. **Run the Macro**

   * Double-click `start.bat`

3. **Set Up Discord Webhook (Optional)**

   * [Find your User/Server/Message ID](https://support.discord.com/hc/en-us/articles/206346498)
   * [Set up a Discord Webhook](https://support.discord.com/hc/en-us/articles/228383668)

---

## ⌨️ Controls

| Action      | Key |
| ----------- | --- |
| Start Macro | F1  |
| Stop Macro  | F2  |
| Stop Macro | ``Alt`` ``S``  |
| Pause Macro | F3  |

---


## 📬 Contact

Need help extracting ZIPs or setting things up?

* **Discord Server:** [link](https://discord.com/invite/Vc465gUXHk)
* **Discord user:** [`_epic.`](https://discord.com/users/726162926851063919)
* **GitHub:** [epicisgood/Grow-a-Garden-Macro](https://github.com/epicisgood/Grow-a-Garden-Macro)
* **Donate:** [Give me Robux!](https://www.roblox.com/games/18130765440/Grow-a-Garden-Donation-Area#!/store)

---

🤑💵💸🐶


